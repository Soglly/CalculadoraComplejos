﻿namespace Calculadora_Complejos
{
    partial class CalculadoraComplejos
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BSumar = new Button();
            Salida = new Label();
            label1 = new Label();
            label2 = new Label();
            z1Real = new TextBox();
            z1Imaginario = new TextBox();
            label3 = new Label();
            label4 = new Label();
            z2Imaginario = new TextBox();
            label5 = new Label();
            label6 = new Label();
            z2Real = new TextBox();
            BElevar = new Button();
            BMultiplicar = new Button();
            BDividir = new Button();
            BRestar = new Button();
            label7 = new Label();
            zImaginario = new TextBox();
            label8 = new Label();
            label9 = new Label();
            zReal = new TextBox();
            label10 = new Label();
            n = new TextBox();
            label11 = new Label();
            label12 = new Label();
            Info = new Label();
            label13 = new Label();
            label14 = new Label();
            Limpiar = new Button();
            SuspendLayout();
            // 
            // BSumar
            // 
            BSumar.Cursor = Cursors.Hand;
            BSumar.Location = new Point(64, 157);
            BSumar.Name = "BSumar";
            BSumar.Size = new Size(75, 29);
            BSumar.TabIndex = 0;
            BSumar.Text = "+";
            BSumar.UseVisualStyleBackColor = true;
            BSumar.Click += BSumar_Click;
            BSumar.MouseEnter += BSumar_MouseEnter;
            BSumar.MouseLeave += BSumar_MouseLeave;
            // 
            // Salida
            // 
            Salida.BackColor = Color.FromArgb(224, 224, 224);
            Salida.BorderStyle = BorderStyle.Fixed3D;
            Salida.Font = new Font("Segoe UI", 27F);
            Salida.Location = new Point(425, 61);
            Salida.Name = "Salida";
            Salida.Size = new Size(342, 125);
            Salida.TabIndex = 1;
            Salida.Click += label1_Click_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(50, 64);
            label1.Name = "label1";
            label1.Size = new Size(20, 15);
            label1.TabIndex = 3;
            label1.Text = "Z1";
            label1.Click += label1_Click_2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(124, 64);
            label2.Name = "label2";
            label2.Size = new Size(15, 15);
            label2.TabIndex = 4;
            label2.Text = "+";
            // 
            // z1Real
            // 
            z1Real.Cursor = Cursors.IBeam;
            z1Real.Location = new Point(76, 61);
            z1Real.Name = "z1Real";
            z1Real.Size = new Size(42, 23);
            z1Real.TabIndex = 2;
            z1Real.TextChanged += textBox1_TextChanged;
            // 
            // z1Imaginario
            // 
            z1Imaginario.Cursor = Cursors.IBeam;
            z1Imaginario.Location = new Point(145, 61);
            z1Imaginario.Name = "z1Imaginario";
            z1Imaginario.Size = new Size(51, 23);
            z1Imaginario.TabIndex = 5;
            z1Imaginario.TextChanged += textBox2_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(202, 64);
            label3.Name = "label3";
            label3.Size = new Size(10, 15);
            label3.TabIndex = 6;
            label3.Text = "i";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(202, 109);
            label4.Name = "label4";
            label4.Size = new Size(10, 15);
            label4.TabIndex = 11;
            label4.Text = "i";
            // 
            // z2Imaginario
            // 
            z2Imaginario.Cursor = Cursors.IBeam;
            z2Imaginario.Location = new Point(145, 101);
            z2Imaginario.Name = "z2Imaginario";
            z2Imaginario.Size = new Size(51, 23);
            z2Imaginario.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(124, 104);
            label5.Name = "label5";
            label5.Size = new Size(15, 15);
            label5.TabIndex = 9;
            label5.Text = "+";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(50, 109);
            label6.Name = "label6";
            label6.Size = new Size(20, 15);
            label6.TabIndex = 8;
            label6.Text = "Z2";
            // 
            // z2Real
            // 
            z2Real.Cursor = Cursors.IBeam;
            z2Real.Location = new Point(76, 101);
            z2Real.Name = "z2Real";
            z2Real.Size = new Size(42, 23);
            z2Real.TabIndex = 7;
            // 
            // BElevar
            // 
            BElevar.Cursor = Cursors.Hand;
            BElevar.Location = new Point(64, 365);
            BElevar.Name = "BElevar";
            BElevar.Size = new Size(75, 29);
            BElevar.TabIndex = 12;
            BElevar.Text = "=";
            BElevar.UseVisualStyleBackColor = true;
            BElevar.Click += BElevar_Click;
            BElevar.MouseEnter += BElevar_MouseEnter;
            BElevar.MouseLeave += BElevar_MouseLeave;
            // 
            // BMultiplicar
            // 
            BMultiplicar.Cursor = Cursors.Hand;
            BMultiplicar.Location = new Point(64, 207);
            BMultiplicar.Name = "BMultiplicar";
            BMultiplicar.Size = new Size(75, 29);
            BMultiplicar.TabIndex = 13;
            BMultiplicar.Text = "X";
            BMultiplicar.UseVisualStyleBackColor = true;
            BMultiplicar.Click += BMultiplicar_Click;
            BMultiplicar.MouseEnter += BMultiplicar_MouseEnter;
            BMultiplicar.MouseLeave += BMultiplicar_MouseLeave;
            // 
            // BDividir
            // 
            BDividir.Cursor = Cursors.Hand;
            BDividir.Location = new Point(145, 207);
            BDividir.Name = "BDividir";
            BDividir.Size = new Size(75, 29);
            BDividir.TabIndex = 14;
            BDividir.Text = "/";
            BDividir.UseVisualStyleBackColor = true;
            BDividir.Click += BDividir_Click;
            BDividir.MouseEnter += BDividir_MouseEnter;
            BDividir.MouseLeave += BDividir_MouseLeave;
            // 
            // BRestar
            // 
            BRestar.Cursor = Cursors.Hand;
            BRestar.Location = new Point(145, 157);
            BRestar.Name = "BRestar";
            BRestar.Size = new Size(75, 29);
            BRestar.TabIndex = 15;
            BRestar.Text = "-";
            BRestar.UseVisualStyleBackColor = true;
            BRestar.Click += BRestar_Click;
            BRestar.MouseEnter += BRestar_MouseEnter;
            BRestar.MouseLeave += BRestar_MouseLeave;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(200, 319);
            label7.Name = "label7";
            label7.Size = new Size(10, 15);
            label7.TabIndex = 20;
            label7.Text = "i";
            // 
            // zImaginario
            // 
            zImaginario.Cursor = Cursors.IBeam;
            zImaginario.Location = new Point(143, 316);
            zImaginario.Name = "zImaginario";
            zImaginario.Size = new Size(51, 23);
            zImaginario.TabIndex = 19;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(122, 319);
            label8.Name = "label8";
            label8.Size = new Size(15, 15);
            label8.TabIndex = 18;
            label8.Text = "+";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(48, 319);
            label9.Name = "label9";
            label9.Size = new Size(14, 15);
            label9.TabIndex = 17;
            label9.Text = "Z";
            label9.Click += label9_Click;
            // 
            // zReal
            // 
            zReal.Cursor = Cursors.IBeam;
            zReal.Location = new Point(74, 316);
            zReal.Name = "zReal";
            zReal.Size = new Size(42, 23);
            zReal.TabIndex = 16;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(216, 316);
            label10.Name = "label10";
            label10.Size = new Size(15, 15);
            label10.TabIndex = 22;
            label10.Text = "^";
            label10.Click += label10_Click;
            // 
            // n
            // 
            n.Cursor = Cursors.IBeam;
            n.Location = new Point(237, 316);
            n.Name = "n";
            n.Size = new Size(51, 23);
            n.TabIndex = 21;
            n.TextChanged += BElevar_MouseEnter;
            // 
            // label11
            // 
            label11.Location = new Point(44, 22);
            label11.Name = "label11";
            label11.Size = new Size(152, 15);
            label11.TabIndex = 23;
            label11.Text = "Operaciones basicas";
            // 
            // label12
            // 
            label12.Location = new Point(42, 280);
            label12.Name = "label12";
            label12.Size = new Size(152, 15);
            label12.TabIndex = 24;
            label12.Text = "Exponenciación";
            label12.Click += label12_Click;
            // 
            // Info
            // 
            Info.BackColor = Color.FromArgb(224, 224, 224);
            Info.BorderStyle = BorderStyle.Fixed3D;
            Info.Font = new Font("Segoe UI", 18F);
            Info.Location = new Point(425, 242);
            Info.Name = "Info";
            Info.Size = new Size(342, 125);
            Info.TabIndex = 25;
            Info.Click += Info_Click;
            // 
            // label13
            // 
            label13.Location = new Point(425, 35);
            label13.Name = "label13";
            label13.Size = new Size(152, 15);
            label13.TabIndex = 26;
            label13.Text = "Resultado";
            label13.Click += label13_Click;
            // 
            // label14
            // 
            label14.Location = new Point(425, 214);
            label14.Name = "label14";
            label14.Size = new Size(152, 15);
            label14.TabIndex = 27;
            label14.Text = "Info";
            // 
            // Limpiar
            // 
            Limpiar.Location = new Point(692, 403);
            Limpiar.Name = "Limpiar";
            Limpiar.Size = new Size(75, 23);
            Limpiar.TabIndex = 28;
            Limpiar.Text = "Limpiar";
            Limpiar.UseVisualStyleBackColor = true;
            Limpiar.Click += button1_Click;
            // 
            // CalculadoraComplejos
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonShadow;
            ClientSize = new Size(800, 450);
            Controls.Add(Limpiar);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(Info);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(n);
            Controls.Add(label7);
            Controls.Add(zImaginario);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(zReal);
            Controls.Add(BRestar);
            Controls.Add(BDividir);
            Controls.Add(BMultiplicar);
            Controls.Add(BElevar);
            Controls.Add(label4);
            Controls.Add(z2Imaginario);
            Controls.Add(label5);
            Controls.Add(label6);
            Controls.Add(z2Real);
            Controls.Add(label3);
            Controls.Add(z1Imaginario);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(z1Real);
            Controls.Add(Salida);
            Controls.Add(BSumar);
            ForeColor = SystemColors.InfoText;
            Name = "CalculadoraComplejos";
            Text = "Calculadora de numeros complejos";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BSumar;
        private Label Salida;
        private Label label1;
        private Label label2;
        private TextBox z1Real;
        private TextBox z1Imaginario;
        private Label label3;
        private Label label4;
        private TextBox z2Imaginario;
        private Label label5;
        private Label label6;
        private TextBox z2Real;
        private Button BElevar;
        private Button BMultiplicar;
        private Button BDividir;
        private Button BRestar;
        private Label label7;
        private TextBox zImaginario;
        private Label label8;
        private Label label9;
        private TextBox zReal;
        private Label label10;
        private TextBox n;
        private Label label11;
        private Label label12;
        private Label Info;
        private Label label13;
        private Label label14;
        private Button Limpiar;
    }
}
