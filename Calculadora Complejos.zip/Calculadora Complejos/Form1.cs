namespace Calculadora_Complejos
{
    public partial class CalculadoraComplejos : Form
    {
        public CalculadoraComplejos()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Info_Click(object sender, EventArgs e)
        {

        }
        //Acciones del boton sumar
        private void BSumar_MouseEnter(object sender, EventArgs e)
        {
            Info.Text = "Suma los numeros complejos en la forma Z1 + Z2";
        }
        private void BSumar_MouseLeave(object sender, EventArgs e)
        {
            Info.Text = "";
        }
        private void BSumar_Click(object sender, EventArgs e)
        {

            try
            {
                int real = int.Parse(z1Real.Text) + int.Parse(z2Real.Text);
                int imaginario = int.Parse(z1Imaginario.Text) + int.Parse(z2Imaginario.Text);

                if (imaginario < 0)
                    Salida.Text = real + " - " + Math.Abs(imaginario) + "i";
                else
                    Salida.Text = real + " + " + imaginario + "i";
            }
            catch (Exception ex)
            {
                Info.Text = "Error: Solo introducir numeros enteros";
            }

        }

        //Acciones del boton restar
        private void BRestar_MouseEnter(object sender, EventArgs e)
        {
            Info.Text = "Resta los numeros complejos en la forma Z1 - Z2";
        }

        private void BRestar_MouseLeave(object sender, EventArgs e)
        {
            Info.Text = "";
        }

        private void BRestar_Click(object sender, EventArgs e)
        {
            try
            {
                int real = int.Parse(z1Real.Text) - int.Parse(z2Real.Text);
                int imaginario = int.Parse(z1Imaginario.Text) - int.Parse(z2Imaginario.Text);
                if (imaginario < 0)
                    Salida.Text = real + " - " + Math.Abs(imaginario) + "i";
                else
                    Salida.Text = real + " + " + Math.Abs(imaginario) + "i";
            }
            catch (Exception ex)
            {
                Info.Text = "Error: Solo introducir numeros enteros";
            }


        }
        // Acciones del boton multiplicar
        private void BMultiplicar_MouseEnter(object sender, EventArgs e)
        {
            Info.Text = "Multiplica los numeros complejos en la forma Z1 x Z2";
        }

        private void BMultiplicar_MouseLeave(object sender, EventArgs e)
        {
            Info.Text = "";
        }
        private void BMultiplicar_Click(object sender, EventArgs e)
        {
            try
            {
                int real = (int.Parse(z1Real.Text) * int.Parse(z2Real.Text)) - (int.Parse(z1Imaginario.Text) * int.Parse(z2Imaginario.Text));
                int imaginario = (int.Parse(z1Real.Text) * int.Parse(z2Imaginario.Text)) + (int.Parse(z2Real.Text) * int.Parse(z1Imaginario.Text));
                if (imaginario < 0)
                    Salida.Text = real + " - " + Math.Abs(imaginario) + "i";
                else
                    Salida.Text = real + " + " + Math.Abs(imaginario) + "i";
            }
            catch (Exception)
            {
                Info.Text = "Error: Solo introducir numeros enteros";
            }
        }
        //Acciones del boton dividir
        private void BDividir_MouseEnter(object sender, EventArgs e)
        {
            Info.Text = "Divide los numeros complejos en la forma Z1 / Z2";
        }

        private void BDividir_MouseLeave(object sender, EventArgs e)
        {
            Info.Text = "";
        }
        private void BDividir_Click(object sender, EventArgs e)
        {
            try
            {
                int real1 = int.Parse(z1Real.Text);
                int imaginario1 = int.Parse(z1Imaginario.Text);
                int real2 = int.Parse(z2Real.Text);
                int imaginario2 = int.Parse(z2Imaginario.Text);
                float divisor = (real2 * real2) + (imaginario2 * imaginario2);
                float real = (real1 * real2) + (imaginario1 * imaginario2);
                float imaginario = (real1 * imaginario2) - (imaginario1 * real2);
                float realFinal = (float)Math.Round(real / divisor, 4);
                float imaginarioFinal = (float)Math.Round(imaginario / divisor, 4);

                if (imaginarioFinal < 0)
                    Salida.Text = realFinal + " - " + Math.Abs(imaginarioFinal) + "i";
                else
                    Salida.Text = realFinal + " + " + Math.Abs(imaginarioFinal) + "i";
            }
            catch (Exception)
            {
                Info.Text = "Error: Solo introducir numeros enteros";
            }
        }
        // Acciones del boton elevar
        private void BElevar_Click(object sender, EventArgs e)
        {
            try
            {
                int bucle = int.Parse(n.Text);
                int real = int.Parse(zReal.Text);
                int imaginario = int.Parse(zImaginario.Text);
                int realElevado = real;
                int imaginarioElevado = imaginario;
                if (bucle < 0)
                {
                    Info.Text = "Error: Solo introducir numeros positivos";
                }
                else if (bucle == 1)
                {
                    if (imaginario < 0)
                        Salida.Text = real + " - " + Math.Abs(imaginario) + "i";

                    else
                        Salida.Text = real + " + " + Math.Abs(imaginario) + "i";
                }
                else if (bucle == 0)
                {
                    Salida.Text = "1";
                }
                else
                {
                    for (int i = 1; i < bucle; i++)
                    {
                        int tempReal = (realElevado * real) - (imaginarioElevado * imaginario);
                        int tempImaginario = (realElevado * imaginario) + (imaginarioElevado * real);
                        realElevado = tempReal;
                        imaginarioElevado = tempImaginario;
                    }
                    if (imaginarioElevado < 0)
                        Salida.Text = realElevado.ToString() + " - " + Math.Abs(imaginarioElevado) + "i";

                    else
                        Salida.Text = realElevado + " + " + Math.Abs(imaginarioElevado) + "i";
                }
            }
            catch
            {
                Info.Text = "Error: Solo introducir numeros enteros";
            }
        }

        private void BElevar_MouseEnter(object sender, EventArgs e)
        {
            Info.Text = "Eleva el numero complejo Z a la potencia POSITIVA n";
        }
        private void BElevar_MouseLeave(object sender, EventArgs e)
        {
            Info.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Salida.Text = "";
        }
    }
}
